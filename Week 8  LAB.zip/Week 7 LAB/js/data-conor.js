var bio = {
"name" : "Conor Ryan",
"role" : "Professor",
"contacts": {
"tel": "353-61-202755",
"email": "conor.ryan@ul.ie",
"github": "ponyLover",
"location": "Limerick"
},
"welcomeMessage": "Welcome to Conor's CV.",
"skills": ["teaching", " research", " ballet"], 
"bioPic": "images/twilight-sparkle-small.png"
};

var work = {"jobs": [
{
"employer" : "University of Limerick",
 "dates" : "2010 - present",
 "title" : "Professor",
 "location": "Limerick",
"description": "Teaching undergraduates and pretending to research."},
{
"employer" : "Royal School of Ballet",
 "dates" : "2001 - 2010",
 "title" : "Labanotation Co-ordinator",
 "location": "London",
    "description": "Responsible for creation, maintenance and analysis of RSB's labanotation archive."},
{"employer" : "Cork City Mortuary",
 "dates" : "1997 - 2001",
 "title" : "Body dresser",
 "location": "Cork",
    "description": "Responsible for choosing appropriate clothing and cosmetics for the recently deceased."}
]}


var education = {
    "schools" : [
{"name" : "University College Cork",
 "location": "Cork",
 "degree": "PhD",
 "major": "Computer Science",
 "dates": 1996,
 "url": "http://www.ucc.ie"},
{"name" : "Royal School of Ballet",
 "location": "London",
 "degree": "BA",
 "major": "Dance",
 "dates": 1992,
 "url": "http://www.rsb.ac.uk"}]
};

var projects = {
	"projects": [
    {"title":"Multicore Attribute Grammatical Evolution",
     "dates":"2012-2016",
     "description":"Using GE to blah ...",
     "images":"images/MAGE.png"
    },
    {"title":"Semi Automated Mammography",
     "dates":"2010-2014",
     "description":"Using GE to perform ...",
     "images":"images/mamm-samp.jpg"
    }
]};
