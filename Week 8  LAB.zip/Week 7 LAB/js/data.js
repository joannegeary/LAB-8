var bio = {
"name" : "Joanne Geary",
"role" : "Student",
"contacts": {
"tel": "0838452366",
"email": "17234905@studentmail.ul.ie",
"github": "Joannegeary",
"location": "Cork"
},
"welcomeMessage": "Welcome to Joanne's CV.",
"skills": ["Singing", " Dancing", " Playing"], 
"bioPic": "https://lh3.googleusercontent.com/91i6hlzkATI82DRvceliPaQpLT_nwJDm2bnw12oLKCItAnte6W-ygXIf8ovv5MOZYoIjhx4GSo3gQnBUK759juygBeTwTcPt1OrcIRgAHPA61RDfNNDIVReNOIDPii_J6yM7I-lNkdzbNPhD0mzh1tCV4iciFKaUNQfbbl79iIXUiiDCU1WBb4n1Fo8Xewave-eSY1ssl-Ymp60-DzUKARmwJO4ReTtrVF6ZPDhPEmwOKZwYppgSc-4zwz5DCcXg5hgeKDmwbsgxw4SsEYTmPvwN10w-7s53vysjcI72TNfzRrKKs3qPNADJpoAKJxq2C3_9W_PMwTWE38OvH42HW8hWNPIGY1NAZl94t3c3dmn4rTWjhnPc7ol4Xxf0ETu72f7ujUBolLtZIMyqGw5cg-_YI4bhxBsIyL65SbFZlawaonlnF3PEXj8C8vGApLXmO5JfV3T7ZddZgpvD_J3QLI0ifkkb_ohYNHCzlNQWdNKy8daU0Inp6YHWX7tAmdXzc7UYCZvBqq1Lfhs2fw0qQwa7JWDivsfVHCd6-sZPmsZZXnqMNnjEhl1XgTgrvAK_rDX0ErJX4NSS872zFkfi8Z54-84riaREt5WRWVsB=w346-h613-no"
};

var work = {"jobs": [
{
"employer" : "Spar",
 "dates" : "2015 - present",
 "title" : "Deli",
 "location": "Cork",
"description": "Cooks and prepares deli food."},

]}



var education = {
    "schools" : [
{"name" : "University Of Limerick",
 "location": "Limerick",
 "degree": "Bachelor Of Science",
 "major": "Digital Media Design",
 "dates": "2017 - present",
 "url": "http://www.ul.ie"},
]
};

var projects = {
	"projects": [
    {"title":"Lourdes",
     "dates":"Summer 2016",
     "description":"I was one of four selected from my school to travel to Lourdes in France and help the eldery during the pilgrimage",
     "images":"https://lh3.googleusercontent.com/_deJOrvmVOu5WADWBLR22IOPhUZqnsb3Jd_1nd_h_1zNKkYfXSiCareXgLFwRhDbEmySCEVEtpdpVI7h3nJ27HNMmeyiMnsPzJYYa8udS7STP72YEeKHwqkd4RFf0mHEOyJk1BXo328UwYGW5ifclyVLkKCTItRXUXFCpjDJPYwJ9DzuZuIMwPP1BWwjzxnvKMegltTbWRfcSgDpVsJq7hNfm3qg9R3CR_2rH33jSAtWNDw7zZr_V60UagfiIWvWyZRyF6XazpuFTHRo7w5N1UCNQKcGE5MuyfJZQOqEC5mjMyB67PZZssHQdNH7x7tNVcgj4Q0JIybGPWR4n7W_4oKPIbh6QHyT5BEUpRYtsFYoIP-yPmpNmjellku-MCSeEk1QwuoDETqZj1-Snx3MlLB8ziMCWxkc3GwX_iSOxWfb2deBRgV4qH6rSY0T35V6jCmChlvC8KGYgUswVIA2Y9TaUMJfgqEuB6LaW2waIoWj9Q3CVu0GYSGwp6Y2GvCQ9CjAs4YDxiZnId7Ttq4Nq75cbmAVyjSjjUPQQDTD1vbSb7SBcMfIEWOKBNl8LlV82_zlnf589fvlVLATOxwOnCjpLldamNjEFCkb1Sc=w960-h542-no"
    },
   
]};
