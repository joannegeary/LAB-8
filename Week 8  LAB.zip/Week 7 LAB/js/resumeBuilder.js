function displayProjects(){
    for (project in projects.projects) {
	$("#projects").append(HTMLprojectStart);
	var formattedTitle = HTMLprojectTitle.replace("%data%",projects.projects[project].title);
	$(".project-entry:last").append(formattedTitle);
	
	var formattedDates = HTMLprojectDates.replace("%data%",projects.projects[project].dates);
	$(".project-entry:last").append(formattedDates);
	var formattedDescription = HTMLprojectDescription.replace("%data%",projects.projects[project].description);
	$(".project-entry:last").append(formattedDescription);
	var formattedImage = HTMLprojectImage.replace("%data%",projects.projects[project].images);
	$(".project-entry:last").append(formattedImage);
    }
}

function displaySchools(){
    for (school in education.schools) {
	$("#education").append(HTMLschoolStart);
	var formattedTitle = HTMLschoolName.replace("%data%",education.schools[school].name);
	var formattedDegree = formattedTitle + HTMLschoolDegree.replace("%data%",education.schools[school].degree);
	$(".education-entry:last").append(formattedDegree);	
	var formattedDate = HTMLschoolDates.replace("%data%",education.schools[school].dates);
	$(".education-entry:last").append(formattedDate);
	var formattedLocation = HTMLschoolLocation.replace("%data%",education.schools[school].location);
	$(".education-entry:last").append(formattedLocation);	
	var formattedMajor =HTMLschoolMajor.replace("%data%",education.schools[school].major);
	$(".education-entry:last").append(formattedMajor);

    }
}

function displayWork() {
    for (job in work.jobs) {
	$("#workExperience").append(HTMLworkStart);
	var formattedEmployer = HTMLworkEmployer.replace("%data%",work.jobs[job].employer);
	var formattedTitle = HTMLworkTitle.replace("%data%",work.jobs[job].title);
	var formattedEmployerTitle = formattedEmployer + formattedTitle;
	$(".work-entry:last").append(formattedEmployerTitle);
	var formattedDates = HTMLworkDates.replace("%data%",work.jobs[job].dates);
	$(".work-entry:last").append(formattedDates);
	var formattedDescription = HTMLworkDescription.replace("%data%",work.jobs[job].description);
	$(".work-entry:last").append(formattedDescription);
	    }
}


displayWork();
displayProjects();
displaySchools();
var name = bio.name;
var formattedName = HTMLheaderName.replace("%data%", name);

var role = bio.role;
var formattedRole = HTMLheaderRole.replace("%data%", role);

var bioPic = bio.bioPic;
var formattedBioPic = HTMLbioPic.replace("%data%", bioPic);

var mobile = bio.contacts.tel;
var formattedMobile = HTMLmobile.replace("%data%", mobile);

var email = bio.contacts.email;
var formattedEmail = HTMLemail.replace("%data%", email);

var github = bio.contacts.github;
var formattedGitHub = HTMLgithub.replace("%data%", github);

var _location = bio.contacts.location;
var formattedLocation = HTMLlocation.replace("%data%", _location);

var welcomeMessage = bio.welcomeMessage;
var formattedWelcomeMessage = HTMLwelcomeMsg.replace("%data%", welcomeMessage);

var skills = bio.skills;
var formattedSkills = HTMLskills.replace("%data%", skills);

var workPosition = work.position;
var formattedWorkPosition = HTMLworkTitle.replace("%data%", workPosition);

var workEmployer = work.employer;
var formattedworkEmployer = HTMLworkEmployer.replace("%data%, workEmployer");

var workDates = work.dates;
var formattedWorkDates = HTMLworkDates.replace("%data%R", workDates);

$("#header").prepend(formattedRole);
$("#header").prepend(formattedName);
$("#topContacts").append(formattedBioPic);
$("#topContacts").append(formattedMobile);
$("#topContacts").append(formattedEmail);
$("#topContacts").append(formattedGitHub);
$("#topContacts").append(formattedLocation);
$("#header").append(formattedWelcomeMessage);
$("#header").append(HTMLskillsStart);
$("#skills").append(formattedSkills);

$("#skills").append(formattedSkills);
